from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, User

class UsuarioManager(BaseUserManager):
    
    def _criar_usuario(self, ra, password, **campos):
        if not ra: 
            raise ValueError("RA deve ser declarado!")
        user = self.model(ra=ra, **campos)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, ra, password=None, **campos):
        return self._criar_usuario(ra, password, **campos)

    def create_superuser(self, ra, password=None, **campos):
        campos.setdefault('perfil', 'C')
        return self._criar_usuario(ra, password, **campos)


# Create your models here.
class Curso(models.Model):

    nome = models.CharField("Nome",max_length=50)
    carga_horaria = models.IntegerField("Carga Horária")
    professor = models.CharField("Coordenador",max_length=50)
    tipo = models.CharField("Tipo",max_length=50)

    descricao = models.TextField("Descrição",blank=True)
    ativo = models.BooleanField("Ativo?",default=True)

    def __str__(self):
        return self.nome

class Usuario(AbstractBaseUser):

    ra = models.IntegerField("RA",unique=True)
    password = models.CharField("Senha", max_length=200)

    nome = models.CharField("Nome", max_length=100)
    email = models.EmailField("E-Mail", max_length=50)

    perfil = models.CharField("Perfil", max_length=1)
    ativo = models.BooleanField("Ativo", default=True)

    USERNAME_FIELD = 'ra'
    REQUIRED_FIELDS = ['nome','email']

    objects = UsuarioManager()

    def get_full_name(self):
        return self.nome

    def get_short_name(self):
        return self.nome

    def __str__(self):  
        return self.nome

    @property
    def is_staff(self):
        return self.perfil == "C"

    def has_module_perms(self, package_name):
        return True

    def has_perm(self, perm, obj=None):
        return True

    def has_perms(self, perm_list, obj=None):
        return True

class Aluno(Usuario):

    celular = models.CharField("Celular", max_length=11)
    curso = models.ForeignKey(Curso)


class NovoUsu(models.Model):
    txtNome = models.CharField("Nome", max_length=100)
    txtCel= models.CharField("Celular",max_length=15)
    txtEmail = models.EmailField("email", max_length=100)
    numRa = models.CharField("RA", max_length=100)
    txtSenha = models.CharField("Senha",max_length=50)