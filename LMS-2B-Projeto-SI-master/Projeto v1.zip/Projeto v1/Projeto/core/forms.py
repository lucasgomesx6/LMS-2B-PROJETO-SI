from django import forms
from core.models import Curso
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from core.models import NovoUsu


class NovoUsuForm(forms.Form):
    txtNome = forms.CharField()
    txtCel= forms.CharField()
    txtEmail = forms.EmailField()
    numRa = forms.CharField()
    txtSenha = forms.CharField()

class CursoForm(forms.ModelForm):

    class Meta:
        model = Curso
        fields = '__all__'


class ContatoForm(forms.Form):

    nome = forms.CharField()
    email = forms.EmailField()
    mensagem = forms.CharField(widget=forms.Textarea())

    def envia_email(self):
        print("Usuário: "+self.cleaned_data["nome"]+
        "\nE-Mail: "+self.cleaned_data["email"]+
        "\nMensagem: "+self.cleaned_data["mensagem"])